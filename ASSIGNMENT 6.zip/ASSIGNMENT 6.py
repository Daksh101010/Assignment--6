import tkinter as tk

def press(key):
    entry.insert(tk.END, key)

def clear():
    entry.delete(0, tk.END)

def calculate():
    try:
        result = eval(entry.get())
        clear()
        entry.insert(0, result)
    except:
        clear()
        entry.insert(0, "Error")

root = tk.Tk()
root.title("Calculator")

# Entry box
entry = tk.Entry(root, width=20, font=("Arial", 18), borderwidth=5)
entry.grid(row=0, column=0, columnspan=4)

# {[Buttons}]
buttons = [
    '7', '8', '9', '/',
    '4', '5', '6', '*',
    '1', '2', '3', '-',
    '0', '.', '=', '+'
]

row = 1
col = 0

for btn in buttons:
    if btn == '=':
        tk.Button(root, text=btn, width=5, height=2,
                  command=calculate).grid(row=row, column=col)
    else:
        tk.Button(root, text=btn, width=5, height=2,
                  command=lambda b=btn: press(b)).grid(row=row, column=col)

    col += 1
    if col == 4:
        col = 0
        row += 1

# Clear button
tk.Button(root, text="C", width=22, height=2,
          command=clear).grid(row=row, column=0, columnspan=4)

root.mainloop()
